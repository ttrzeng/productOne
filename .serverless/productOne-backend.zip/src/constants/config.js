const config = {
  stripe: {
    apiKey: "pk_test_Sxty0EV41BFQWSsOJm5qk447",
    apiUrl: "https://t0yemh84ka.execute-api.us-east-1.amazonaws.com/dev/charges",
    currency: "CAD"
  }
};

export default config;
