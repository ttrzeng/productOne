export const config = {
  stripe: {
    apiUrl: 'https://hoqfdn3a0g.execute-api.us-east-1.amazonaws.com/production/charges',
    apiKey: 'pk_test_Sxty0EV41BFQWSsOJm5qk447',
    currency: 'CAD'
  }
};
