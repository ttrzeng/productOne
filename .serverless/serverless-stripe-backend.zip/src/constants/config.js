const config = {
  stripe: {
    apiUrl: 'https://api.stripe.com/v1/charges',
    apiKey: 'pk_test_Sxty0EV41BFQWSsOJm5qk447',
    currency: 'CAD'
  }
}

export default config;
