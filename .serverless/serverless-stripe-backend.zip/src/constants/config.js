export const config = {
  stripe: {
    apiUrl: 'https://kmwmrg4d01.execute-api.ap-southeast-1.amazonaws.com/dev/charges',
    apiKey: 'pk_test_Sxty0EV41BFQWSsOJm5qk447',
    currency: 'CAD'
  }
};
